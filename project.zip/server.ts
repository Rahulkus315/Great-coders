import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import { createServer as createViteServer } from 'vite';
import { apiRouter } from './server/routes';
import { runMidnightSettlement } from './server/settlementEngine';
import { getISTNow, getISTDateString, TIMEZONE } from './server/timeUtils';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT || 3000);

  // Parse JSON payloads
  app.use(express.json({ limit: '10mb' }));
  app.use(cookieParser());

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Great Coders',
      currentIST: getISTNow().toISOString(),
      timezone: TIMEZONE,
    });
  });

  // API routes mounted FIRST
  app.use('/api', apiRouter);

  // Scheduled background check for 00:00 IST Midnight Settlement (Section 25)
  let lastSettledDate = '';
  setInterval(() => {
    try {
      const now = getISTNow();
      const timeFormatter = new Intl.DateTimeFormat('en-GB', {
        timeZone: TIMEZONE,
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
      const [hour, minute] = timeFormatter.format(now).split(':').map(Number);
      const currentDate = getISTDateString(now);

      // Trigger at 00:00 or 00:01 IST if not yet settled for today
      if (hour === 0 && minute <= 5 && lastSettledDate !== currentDate) {
        console.log(`[Midnight Scheduler] Triggering automatic 00:00 IST settlement for ${currentDate}...`);
        lastSettledDate = currentDate;
        runMidnightSettlement(currentDate);
      }
    } catch (err) {
      console.error('[Midnight Scheduler] Error during background check:', err);
    }
  }, 60 * 1000);

  // Vite middleware for development vs static build for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
