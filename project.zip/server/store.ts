import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  User,
  DailyTask,
  DSAProblem,
  InterviewQuestion,
  TaskUserStatus,
  PointLedgerEntry,
  DSAAttempt,
  PermissionRequest,
  DailyJournal,
  HabitEntry,
  AppNotification,
  AuditLogEntry,
  MotivationQuote,
  MorningCheckin,
  LeaveDay,
  DailyCheckinRecord,
  AuthenticationIdentity,
} from '../src/types';
import { generateCurriculum, MOTIVATION_QUOTES } from './curriculumData';
import { getISTDateString, getISTNow } from './timeUtils';

export interface ParticipantProfile {
  displayName: string;
  headline: string;
  bio: string;
  skills: string;
  coverTheme: 'default' | 'developer' | 'java' | 'ai' | 'backend' | 'fullstack';
  avatarUrl?: string;
}

export interface AppState {
  users: Array<User & { passwordHash: string }>;
  profiles: Record<string, ParticipantProfile>;
  tasks: DailyTask[];
  dsaProblems: DSAProblem[];
  interviewQuestions: InterviewQuestion[];
  quotes: MotivationQuote[];
  taskStatuses: TaskUserStatus[];
  pointLedger: PointLedgerEntry[];
  dsaAttempts: DSAAttempt[];
  permissions: PermissionRequest[];
  journals: DailyJournal[];
  habits: HabitEntry[];
  morningCheckins: MorningCheckin[];
  dailyCheckins: DailyCheckinRecord[];
  leaves: LeaveDay[];
  notifications: AppNotification[];
  auditLogs: AuditLogEntry[];
  authIdentities: AuthenticationIdentity[];
  frozenDays: string[]; // Dates that have completed midnight settlement
  simulatedDate: string | null;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const STATE_FILE = path.join(DATA_DIR, 'app_state.json');

// Default initial password hash for 'password123'
const DEFAULT_PASSWORD_HASH = bcrypt.hashSync('password123', 10);

class Store {
  private state: AppState;

  constructor() {
    this.ensureDataDirectory();
    this.state = this.loadState();
  }

  private ensureDataDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadState(): AppState {
    if (fs.existsSync(STATE_FILE)) {
      try {
        const raw = fs.readFileSync(STATE_FILE, 'utf-8');
        return JSON.parse(raw);
      } catch (err) {
        console.error('Error reading app_state.json, creating new seed state:', err);
      }
    }
    const initialState = this.createInitialSeedState();
    this.saveStateDirect(initialState);
    return initialState;
  }

  public save() {
    this.saveStateDirect(this.state);
  }

  private saveStateDirect(state: AppState) {
    try {
      this.ensureDataDirectory();
      const tmpFile = `${STATE_FILE}.tmp`;
      fs.writeFileSync(tmpFile, JSON.stringify(state, null, 2), 'utf-8');
      fs.renameSync(tmpFile, STATE_FILE);
    } catch (err) {
      console.error('Failed to write app_state.json:', err);
    }
  }

  public getState(): AppState {
    this.state.dailyCheckins = this.state.dailyCheckins || [];
    this.state.leaves = this.state.leaves || [];
    this.state.morningCheckins = this.state.morningCheckins || [];
    return this.state;
  }

  public resetToSeedState() {
    this.state = this.createInitialSeedState();
    this.save();
    return this.state;
  }

  private createInitialSeedState(): AppState {
    const { tasks, dsaProblems, interviewQuestions } = generateCurriculum();

    const users: Array<User & { passwordHash: string }> = [
      {
        id: 'user-rahul',
        name: 'Rahul',
        email: 'rahulkushwha181@gmail.com',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        targetRole: 'Senior Java Backend Engineer & System Architect',
        boundIdentity: 'identity-lock-rahul-001',
        createdAt: '2026-09-01T00:00:00Z',
        passwordHash: DEFAULT_PASSWORD_HASH,
      },
      {
        id: 'user-dileep',
        name: 'Dileep',
        email: 'dileep@devchallenge.com',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        targetRole: 'Senior Full-Stack & Spring Boot Specialist',
        boundIdentity: 'identity-lock-dileep-002',
        createdAt: '2026-09-01T00:00:00Z',
        passwordHash: DEFAULT_PASSWORD_HASH,
      },
    ];

    const pointLedger: PointLedgerEntry[] = [];
    const taskStatuses: TaskUserStatus[] = [];
    const dsaAttempts: DSAAttempt[] = [];
    const habits: HabitEntry[] = [];
    const journals: DailyJournal[] = [];
    const morningCheckins: MorningCheckin[] = [];
    const dailyCheckins: DailyCheckinRecord[] = [];
    const leaves: LeaveDay[] = [];
    const frozenDays: string[] = [];

    const authIdentities: AuthenticationIdentity[] = [];

    const profiles: Record<string, ParticipantProfile> = {
      'user-rahul': {
        displayName: 'Rahul',
        headline: 'Java Backend • DSA • System Design',
        bio: 'Building every day. Becoming a better coder.',
        skills: 'Java Backend • DSA • React • Spring Boot',
        coverTheme: 'default',
        avatarUrl: users[0].avatar,
      },
      'user-dileep': {
        displayName: 'Dileep',
        headline: 'Full Stack • Spring Boot • Product Thinking',
        bio: 'Building every day. Becoming a better coder.',
        skills: 'Java • Spring Boot • DSA • Full Stack',
        coverTheme: 'developer',
        avatarUrl: users[1].avatar,
      },
    };

    const notifications: AppNotification[] = [
      {
        id: 'notif-welcome-rahul',
        userId: 'user-rahul',
        type: 'COMPETITION_ALERT',
        title: '🎯 Great Coders Challenge Started',
        message: 'Welcome Rahul! Your Great Coders journey begins today. Keep your daily streak strong and stay focused on execution.',
        read: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'notif-welcome-dileep',
        userId: 'user-dileep',
        type: 'COMPETITION_ALERT',
        title: '🎯 Great Coders Challenge Started',
        message: 'Welcome Dileep! Your Great Coders journey begins today. Keep your daily streak strong and stay focused on execution.',
        read: false,
        createdAt: new Date().toISOString(),
      },
    ];

    const auditLogs: AuditLogEntry[] = [
      {
        id: 'audit-1',
        actorId: 'SYSTEM',
        actorName: 'SYSTEM',
        action: 'INITIALIZE_CHALLENGE',
        targetType: 'CHALLENGE',
        targetId: '100_DAY_CHALLENGE',
        reason: 'Initialized production 100-day curriculum for Rahul and Dileep (Sep 15 - Dec 31, 2026)',
        timestamp: '2026-09-15T00:00:00+05:30',
      },
    ];

    return {
      users,
      profiles,
      tasks,
      dsaProblems,
      interviewQuestions,
      quotes: MOTIVATION_QUOTES,
      taskStatuses,
      pointLedger,
      dsaAttempts,
      permissions: [],
      journals,
      habits,
      morningCheckins,
      dailyCheckins,
      leaves,
      notifications,
      auditLogs,
      authIdentities,
      frozenDays,
      simulatedDate: null,
    };
  }
}

export const store = new Store();
