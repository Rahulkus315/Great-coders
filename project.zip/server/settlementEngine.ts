import { store } from './store';
import { calculateDayInfo, getISTDateString, getISTNow } from './timeUtils';
import { calculateUserStats } from './scoringEngine';

export function runMidnightSettlement(targetDateStr?: string) {
  const state = store.getState();
  const dayInfo = calculateDayInfo();

  // If not provided, target the previous completed day or today if requested
  const dateToSettle = targetDateStr || dayInfo.currentDate;

  // Check if already frozen
  if (state.frozenDays.includes(dateToSettle)) {
    return {
      success: false,
      message: `Day ${dateToSettle} has already been finalized and settled.`,
    };
  }

  const taskForDay = state.tasks.find(t => t.date === dateToSettle);
  const nowIso = getISTNow().toISOString();

  const finalizeSelfControlForUser = (userId: 'user-rahul' | 'user-dileep') => {
    const todayHabit = state.habits.find(h => h.userId === userId && h.date === dateToSettle);
    const isHoliday = (state.leaves || []).some(l => l.userId === userId && l.date === dateToSettle);

    if (isHoliday) {
      const holidayEntry = state.habits.find(h => h.userId === userId && h.date === dateToSettle && h.status === 'HOLIDAY');
      if (!holidayEntry) {
        state.habits.push({
          id: `habit-holiday-${userId}-${Date.now()}`,
          userId: userId,
          date: dateToSettle,
          status: 'HOLIDAY',
          recordedAt: nowIso,
        });
      }
      return;
    }

    if (todayHabit && todayHabit.status === 'REPORTED_RELAPSE') {
      todayHabit.recordedAt = nowIso;
      return;
    }

    if (!todayHabit) {
      state.habits.push({
        id: `habit-no-report-${userId}-${Date.now()}`,
        userId: userId,
        date: dateToSettle,
        status: 'NO_REPORT',
        recordedAt: nowIso,
      });
    } else if (todayHabit.status === 'NO_REPORT') {
      todayHabit.recordedAt = nowIso;
    }
  };

  finalizeSelfControlForUser('user-rahul');
  finalizeSelfControlForUser('user-dileep');

  let rahulPointsToday = 0;
  let dileepPointsToday = 0;
  let rahulCompletedToday = 0;
  let dileepCompletedToday = 0;
  let rahulMissedToday = 0;
  let dileepMissedToday = 0;

  const rahulOnLeave = (state.leaves || []).some(l => l.userId === 'user-rahul' && l.date === dateToSettle);
  const dileepOnLeave = (state.leaves || []).some(l => l.userId === 'user-dileep' && l.date === dateToSettle);

  if (taskForDay) {
    // Check Rahul (skip if on approved leave/holiday)
    if (!rahulOnLeave) {
      let rahulStatus = state.taskStatuses.find(
        ts => ts.userId === 'user-rahul' && ts.taskId === taskForDay.id
      );

      if (!rahulStatus || rahulStatus.status === 'PENDING') {
        // Apply -5 penalty!
        rahulMissedToday++;
        const rahulEntries = state.pointLedger.filter(e => e.userId === 'user-rahul');
        const rRunning = rahulEntries.reduce((s, e) => s + e.points, 0);

        state.pointLedger.push({
          id: `ledger-settle-r-${Date.now()}`,
          userId: 'user-rahul',
          date: dateToSettle,
          timestamp: nowIso,
          eventType: 'TASK_MISSED_SETTLEMENT',
          points: -5,
          runningTotal: rRunning - 5,
          sourceTaskId: taskForDay.id,
          sourceTaskTitle: taskForDay.title,
          category: taskForDay.category,
          reason: `Midnight Settlement: Daily task was not completed by 00:00 IST (-5 penalty)`,
        });

        if (!rahulStatus) {
          state.taskStatuses.push({
            taskId: taskForDay.id,
            userId: 'user-rahul',
            status: 'MISSED',
            pointsAwarded: -5,
          });
        } else {
          rahulStatus.status = 'MISSED';
          rahulStatus.pointsAwarded = -5;
        }
        rahulPointsToday -= 5;
      } else if (rahulStatus.status === 'COMPLETED_ON_TIME') {
        rahulCompletedToday++;
        rahulPointsToday += 4;
      }
    }

    // Check Dileep (skip if on approved leave/holiday)
    if (!dileepOnLeave) {
      let dileepStatus = state.taskStatuses.find(
        ts => ts.userId === 'user-dileep' && ts.taskId === taskForDay.id
      );

      if (!dileepStatus || dileepStatus.status === 'PENDING') {
        // Apply -5 penalty!
        dileepMissedToday++;
        const dileepEntries = state.pointLedger.filter(e => e.userId === 'user-dileep');
        const dRunning = dileepEntries.reduce((s, e) => s + e.points, 0);

        state.pointLedger.push({
          id: `ledger-settle-d-${Date.now()}`,
          userId: 'user-dileep',
          date: dateToSettle,
          timestamp: nowIso,
          eventType: 'TASK_MISSED_SETTLEMENT',
          points: -5,
          runningTotal: dRunning - 5,
          sourceTaskId: taskForDay.id,
          sourceTaskTitle: taskForDay.title,
          category: taskForDay.category,
          reason: `Midnight Settlement: Daily task was not completed by 00:00 IST (-5 penalty)`,
        });

        if (!dileepStatus) {
          state.taskStatuses.push({
            taskId: taskForDay.id,
            userId: 'user-dileep',
            status: 'MISSED',
            pointsAwarded: -5,
          });
        } else {
          dileepStatus.status = 'MISSED';
          dileepStatus.pointsAwarded = -5;
        }
        dileepPointsToday -= 5;
      } else if (dileepStatus.status === 'COMPLETED_ON_TIME') {
        dileepCompletedToday++;
        dileepPointsToday += 4;
      }
    }
  }

  // Freeze date
  state.frozenDays.push(dateToSettle);

  // Calculate updated stats
  const rahulStats = calculateUserStats('user-rahul');
  const dileepStats = calculateUserStats('user-dileep');

  const leader =
    rahulStats.totalPoints > dileepStats.totalPoints
      ? 'Rahul'
      : dileepStats.totalPoints > rahulStats.totalPoints
      ? 'Dileep'
      : 'Tied';
  const gap = Math.abs(rahulStats.totalPoints - dileepStats.totalPoints);

  // Generate Midnight Summary notifications for both users
  const summaryMsg = `Day ${taskForDay?.dayNumber || 1} Final Result: Rahul ${rahulPointsToday >= 0 ? '+' : ''}${rahulPointsToday} pts (${rahulCompletedToday} complete, ${rahulMissedToday} missed) | Dileep ${dileepPointsToday >= 0 ? '+' : ''}${dileepPointsToday} pts (${dileepCompletedToday} complete, ${dileepMissedToday} missed). Current Leader: ${leader} (Gap: ${gap} pts).`;

  state.notifications.unshift({
    id: `notif-settle-r-${Date.now()}`,
    userId: 'user-rahul',
    type: 'MIDNIGHT_SUMMARY',
    title: `🌙 Midnight Settlement Finalized (${dateToSettle})`,
    message: summaryMsg,
    read: false,
    createdAt: nowIso,
  });

  state.notifications.unshift({
    id: `notif-settle-d-${Date.now()}`,
    userId: 'user-dileep',
    type: 'MIDNIGHT_SUMMARY',
    title: `🌙 Midnight Settlement Finalized (${dateToSettle})`,
    message: summaryMsg,
    read: false,
    createdAt: nowIso,
  });

  // Audit log
  state.auditLogs.unshift({
    id: `audit-settle-${Date.now()}`,
    actorId: 'SYSTEM',
    actorName: 'SYSTEM',
    action: 'MIDNIGHT_SETTLEMENT',
    targetType: 'DAY_SETTLEMENT',
    targetId: dateToSettle,
    reason: summaryMsg,
    timestamp: nowIso,
  });

  store.save();

  return {
    success: true,
    message: `Midnight settlement for ${dateToSettle} completed successfully.`,
    summary: summaryMsg,
    rahulStats,
    dileepStats,
  };
}
