import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  Lock,
  Flame,
  AlertCircle,
  ChevronRight,
  Filter,
  Layers,
  Star,
  BookOpen,
  Code2,
  Pencil,
  X,
} from 'lucide-react';
import { DailyTask, PermissionRequest, TaskCompletionStatus } from '../types';

interface RoadmapViewProps {
  tasks: Array<DailyTask & { userStatus: TaskCompletionStatus; dsaSolved: boolean; isCurrentDay: boolean; isLocked: boolean }>;
  currentDayNumber: number;
  pendingScheduleRequests?: PermissionRequest[];
  onSelectDay: (dayNumber: number) => void;
  onRequestScheduleChange?: (payload: { entityId: string; entityType: 'TASK' | 'DSA'; proposedDay: number; reason: string }) => Promise<void>;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({
  tasks,
  currentDayNumber,
  pendingScheduleRequests = [],
  onSelectDay,
  onRequestScheduleChange,
}) => {
  const [selectedMonth, setSelectedMonth] = useState<number>(1);
  const [priorityFilter, setPriorityFilter] = useState<'ALL' | 'HIGH' | 'COMPLETED' | 'PENDING'>('ALL');
  const [editTarget, setEditTarget] = useState<{ task: DailyTask; currentDay: number } | null>(null);
  const [proposedDay, setProposedDay] = useState<number>(1);
  const [reason, setReason] = useState<string>('');
  const [submittingChange, setSubmittingChange] = useState(false);
  const [changeFeedback, setChangeFeedback] = useState<string | null>(null);

  const monthConfigs = [
    {
      month: 1,
      title: 'Month 1: Java & DSA Foundations',
      subtitle: 'Core Java syntax, JVM architecture, OOP mastery & DSA fundamentals',
      startDay: 1,
      endDay: 28,
      dates: '14 Sep 2026 – 11 Oct 2026',
    },
    {
      month: 2,
      title: 'Month 2: Advanced Java, Concurrency, SQL & Hibernate',
      subtitle: 'Modern Java 8-21, multithreading, relational databases & ORM engineering',
      startDay: 29,
      endDay: 56,
      dates: '12 Oct 2026 – 08 Nov 2026',
    },
    {
      month: 3,
      title: 'Month 3: Spring Boot, REST APIs, Security & React',
      subtitle: 'Enterprise Spring Boot 3, Spring Security 6, JWT, Full-Stack React & Graphs',
      startDay: 57,
      endDay: 84,
      dates: '09 Nov 2026 – 06 Dec 2026',
    },
    {
      month: 4,
      title: 'Month 4: System Design, Capstones & Final Crucible',
      subtitle: 'Advanced backend patterns, hard DP, system design, mock interviews & finale',
      startDay: 85,
      endDay: 100,
      dates: '07 Dec 2026 – 23 Dec 2026',
    },
  ];

  const currentConfig = monthConfigs.find(m => m.month === selectedMonth)!;
  const monthTasks = tasks.filter(
    t => t.dayNumber >= currentConfig.startDay && t.dayNumber <= currentConfig.endDay
  );

  // Month progress
  const completedInMonth = monthTasks.filter(
    t => t.userStatus === 'COMPLETED_ON_TIME' || t.userStatus === 'COMPLETED_LATE'
  ).length;
  const monthProgress = Math.round((completedInMonth / monthTasks.length) * 100) || 0;

  // Filter tasks
  const filteredTasks = monthTasks.filter(t => {
    if (priorityFilter === 'HIGH') return t.priority === 'HIGH';
    if (priorityFilter === 'COMPLETED')
      return t.userStatus === 'COMPLETED_ON_TIME' || t.userStatus === 'COMPLETED_LATE';
    if (priorityFilter === 'PENDING')
      return t.userStatus === 'PENDING' || t.userStatus === 'MISSED';
    return true;
  });

  const handleSubmitScheduleRequest = async () => {
    if (!editTarget || !onRequestScheduleChange) return;
    if (!reason.trim()) {
      setChangeFeedback('Please include a reason so the other participant can review the change properly.');
      return;
    }
    setSubmittingChange(true);
    setChangeFeedback(null);
    try {
      await onRequestScheduleChange({
        entityId: editTarget.task.id,
        entityType: 'TASK',
        proposedDay,
        reason: reason.trim(),
      });
      setEditTarget(null);
      setReason('');
      setProposedDay(1);
    } catch (err) {
      setChangeFeedback(err instanceof Error ? err.message : 'Failed to submit schedule change request.');
    } finally {
      setSubmittingChange(false);
    }
  };

  const hasPendingRequest = (taskId: string) =>
    pendingScheduleRequests.some(req => req.entityId === taskId && req.status === 'PENDING');

  return (
    <div className="space-y-6">
      {/* Month Navigation Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {monthConfigs.map(m => {
          const isSelected = selectedMonth === m.month;
          const isActiveMonth = currentDayNumber >= m.startDay && currentDayNumber <= m.endDay;
          const mTasks = tasks.filter(t => t.dayNumber >= m.startDay && t.dayNumber <= m.endDay);
          const mCompleted = mTasks.filter(
            t => t.userStatus === 'COMPLETED_ON_TIME' || t.userStatus === 'COMPLETED_LATE'
          ).length;
          const mPct = Math.round((mCompleted / mTasks.length) * 100) || 0;

          return (
            <button
              key={m.month}
              type="button"
              onClick={() => setSelectedMonth(m.month)}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                isSelected
                  ? 'bg-slate-900 border-indigo-500 ring-1 ring-indigo-500/50 shadow-lg'
                  : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/60'
              }`}
            >
              {isActiveMonth && (
                <span className="absolute top-2.5 right-2.5 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                </span>
              )}

              <div className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                Month {m.month} {isActiveMonth && '• Current'}
              </div>
              <h4 className="text-sm font-semibold text-slate-100 mt-1 line-clamp-1">
                {m.title.split(':')[1] || m.title}
              </h4>
              <div className="text-[11px] text-slate-400 mt-0.5">{m.dates}</div>

              {/* Progress mini bar */}
              <div className="mt-3">
                <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                  <span>{mCompleted}/{mTasks.length} Days</span>
                  <span>{mPct}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-500 rounded-full transition-all"
                    style={{ width: `${mPct}%` }}
                  ></div>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Month Header & Filter Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-slate-100">{currentConfig.title}</h3>
            <p className="text-xs text-slate-400 mt-0.5">{currentConfig.subtitle}</p>
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={priorityFilter}
              onChange={e => setPriorityFilter(e.target.value as any)}
              className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Topics ({monthTasks.length})</option>
              <option value="HIGH">🔴 High Priority Must-Know</option>
              <option value="COMPLETED">✅ Completed</option>
              <option value="PENDING">⏳ Pending / Upcoming</option>
            </select>
          </div>
        </div>

        {/* Progress summary for this month */}
        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs text-slate-400 font-medium">Month Completion Rate:</span>
            <div className="text-xl font-bold text-slate-200">
              {completedInMonth} <span className="text-xs text-slate-400 font-normal">of {monthTasks.length} curriculum days</span>
            </div>
          </div>
          <div className="w-full sm:w-64">
            <div className="flex justify-between text-xs text-slate-300 font-medium mb-1">
              <span>Progress</span>
              <span className="text-indigo-400">{monthProgress}%</span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 rounded-full transition-all"
                style={{ width: `${monthProgress}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Day Curriculum Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTasks.map(t => {
          const isDone = t.userStatus === 'COMPLETED_ON_TIME' || t.userStatus === 'COMPLETED_LATE';
          const isMissed = t.userStatus === 'MISSED';

          const isFuture = t.dayNumber > currentDayNumber;
          const pending = hasPendingRequest(t.id);

          return (
            <div
              key={t.id}
              onClick={() => onSelectDay(t.dayNumber)}
              className={`p-5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between hover:shadow-lg ${
                t.isCurrentDay
                  ? 'bg-indigo-950/25 border-indigo-500/70 ring-1 ring-indigo-500/40'
                  : isDone
                  ? 'bg-slate-900/90 border-emerald-500/30 hover:border-emerald-500/50'
                  : isMissed
                  ? 'bg-slate-900/90 border-rose-500/30'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-bold text-indigo-400">
                    Day {t.dayNumber} • {t.date}
                  </span>
                  {t.isCurrentDay && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      TODAY
                    </span>
                  )}
                  {isDone && (
                    <span className="text-emerald-400 text-xs font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Done
                    </span>
                  )}
                  {isMissed && (
                    <span className="text-rose-400 text-xs font-semibold">
                      Missed (-5)
                    </span>
                  )}
                </div>

                <h4 className="text-sm font-bold text-slate-100 line-clamp-2 leading-snug">
                  {t.title}
                </h4>

                <div className="flex flex-wrap gap-1.5 mt-2.5">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                    {t.category.replace('_', ' ')}
                  </span>
                  {t.priority === 'HIGH' && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-rose-500/10 text-rose-300 border border-rose-500/30">
                      Must Know
                    </span>
                  )}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 gap-2">
                <span className="flex items-center gap-1">
                  <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                  {t.dsaSolved ? 'DSA Solved' : 'DSA Pending'}
                </span>
                <div className="flex items-center gap-2">
                  {isFuture && onRequestScheduleChange && (
                    <button
                      type="button"
                      onClick={e => {
                        e.stopPropagation();
                        setEditTarget({ task: t, currentDay: t.dayNumber });
                        setProposedDay(t.dayNumber);
                        setReason('');
                        setChangeFeedback(null);
                      }}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-amber-500/15 border border-amber-500/30 text-[10px] font-bold text-amber-300 hover:bg-amber-500/25 transition-colors cursor-pointer"
                    >
                      <Pencil className="w-3 h-3" />
                      {pending ? 'Pending Approval' : 'Edit'}
                    </button>
                  )}
                  <span className="text-indigo-400 font-semibold flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                    Inspect Day <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {editTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl max-w-lg w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-base font-bold text-slate-100">Edit Future Task</h4>
                <p className="text-xs text-slate-400">Mutual approval is required before the change becomes active.</p>
              </div>
              <button
                type="button"
                onClick={() => setEditTarget(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-sm text-slate-300">
              <div className="bg-slate-950/70 rounded-xl p-3 border border-slate-800">
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Task</div>
                <div className="font-semibold text-slate-100 mt-1">{editTarget.task.title}</div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-slate-950/70 rounded-xl p-3 border border-slate-800">
                  <div className="text-[10px] uppercase tracking-wider text-slate-400">Current Schedule</div>
                  <div className="font-semibold text-slate-100 mt-1">Day {editTarget.task.dayNumber}</div>
                </div>
                <div className="bg-slate-950/70 rounded-xl p-3 border border-slate-800">
                  <label className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1">Proposed Day</label>
                  <input
                    type="number"
                    min={currentDayNumber + 1}
                    max={100}
                    value={proposedDay}
                    onChange={e => setProposedDay(Number(e.target.value) || currentDayNumber + 1)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <label className="block text-[10px] uppercase tracking-wider text-slate-400">Reason</label>
              <textarea
                value={reason}
                onChange={e => setReason(e.target.value)}
                rows={3}
                placeholder="Move this topic after Collections."
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {changeFeedback && (
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-200 text-xs p-2.5">
                {changeFeedback}
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditTarget(null)}
                className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmitScheduleRequest}
                disabled={submittingChange || !reason.trim()}
                className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {submittingChange ? 'Submitting...' : 'Submit Change Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
