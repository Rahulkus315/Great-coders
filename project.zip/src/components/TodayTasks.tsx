import React, { useState } from 'react';
import {
  CheckCircle,
  Clock,
  BookOpen,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  RotateCcw,
  Code2,
  Send,
  HelpCircle,
  Flame,
  Award,
  Lock,
  Moon,
} from 'lucide-react';
import { DailyTask, DSAProblem, TaskCompletionStatus, LearningWindowStatus } from '../types';
import { ConfirmationModal } from './ConfirmationModal';
import confetti from 'canvas-confetti';
import { Palmtree } from 'lucide-react';

interface TodayTasksProps {
  task: DailyTask | null;
  dsaProblem: DSAProblem | null;
  taskStatus: TaskCompletionStatus;
  dsaSolved: boolean;
  windowStatus: LearningWindowStatus;
  reversalCooldownText?: string;
  isReversalBlocked?: boolean;
  isOnLeaveToday?: boolean;
  isNightLockdown?: boolean;
  onOpenLeavesModal?: () => void;
  onCompleteTask: () => Promise<void>;
  onRequestReversal: (reason: string) => Promise<void>;
  onSubmitDsaAttempt: (timeMinutes: number, notes: string) => Promise<void>;
}

export const TodayTasks: React.FC<TodayTasksProps> = ({
  task,
  dsaProblem,
  taskStatus,
  dsaSolved,
  windowStatus,
  reversalCooldownText,
  isReversalBlocked,
  isOnLeaveToday = false,
  isNightLockdown = false,
  onOpenLeavesModal,
  onCompleteTask,
  onRequestReversal,
  onSubmitDsaAttempt,
}) => {
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showReversalModal, setShowReversalModal] = useState(false);
  const [reversalReason, setReversalReason] = useState('');
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>(null);

  // DSA attempt state
  const [dsaMinutes, setDsaMinutes] = useState(35);
  const [dsaNotes, setDsaNotes] = useState('');
  const [isSubmittingDsa, setIsSubmittingDsa] = useState(false);

  const isCompleted = taskStatus === 'COMPLETED_ON_TIME' || taskStatus === 'COMPLETED_LATE';

  const handleConfirmCompletion = async () => {
    setShowConfirmModal(false);
    await onCompleteTask();
    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  const handleSendReversal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reversalReason.trim()) return;
    await onRequestReversal(reversalReason);
    setShowReversalModal(false);
    setReversalReason('');
  };

  const handleDsaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingDsa(true);
    try {
      await onSubmitDsaAttempt(dsaMinutes, dsaNotes);
      confetti({
        particleCount: 50,
        spread: 40,
        origin: { y: 0.8 },
      });
    } finally {
      setIsSubmittingDsa(false);
    }
  };

  if (isOnLeaveToday || !task) {
    return (
      <div className="bg-sky-950/20 border border-sky-500/30 rounded-2xl p-8 sm:p-10 text-center space-y-4 shadow-xl">
        <div className="w-16 h-16 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center mx-auto">
          <Palmtree className="w-8 h-8" />
        </div>
        <div className="max-w-md mx-auto space-y-2">
          <h3 className="text-xl font-bold text-slate-100">
            {isOnLeaveToday ? 'Approved Holiday Active' : 'No Scheduled Task Today'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {isOnLeaveToday
              ? 'You have utilized an approved holiday today. Daily tasks and DSA challenges have shifted forward by 1 day. Points and streaks are 100% safeguarded.'
              : 'You are currently off schedule or all curriculum milestones have been satisfied.'}
          </p>
        </div>
        {onOpenLeavesModal && (
          <button
            type="button"
            onClick={onOpenLeavesModal}
            className="px-4 py-2 rounded-xl bg-sky-600/30 hover:bg-sky-600/40 text-sky-200 border border-sky-500/40 text-xs font-semibold cursor-pointer transition-colors"
          >
            Manage Holiday Quota (5 Total)
          </button>
        )}
      </div>
    );
  }

  const priorityColor =
    task.priority === 'HIGH'
      ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
      : task.priority === 'MEDIUM'
      ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';

  return (
    <div className="space-y-6">
      {/* 1. Daily Core Learning Task */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        {/* Status indicator badge */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Day {task.dayNumber} • {task.category.replace('_', ' ')}
            </span>
            <span className={`px-2 py-0.5 rounded text-xs font-semibold border ${priorityColor}`}>
              {task.priority === 'HIGH' ? '🔴 HIGH PRIORITY' : task.priority === 'MEDIUM' ? '🟠 MEDIUM' : '🟢 LOW'}
            </span>
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" /> ~{task.estimatedMinutes} mins
            </span>
          </div>

          <div>
            {isCompleted ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                {taskStatus === 'COMPLETED_ON_TIME' ? 'COMPLETED ON TIME (+4 PTS)' : 'COMPLETED LATE (+2 PTS)'}
              </span>
            ) : taskStatus === 'MISSED' ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-500/15 text-rose-300 border border-rose-500/30">
                MISSED SETTLEMENT (-5 PTS)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                PENDING COMPLETION
              </span>
            )}
          </div>
        </div>

        {/* Task Title & Badges */}
        <div className="mt-5 space-y-3">
          <h3 className="text-xl font-bold text-slate-100 leading-snug">{task.title}</h3>

          <div className="flex flex-wrap gap-1.5">
            {task.badges.map((badge, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-800 text-slate-300 border border-slate-700"
              >
                {badge}
              </span>
            ))}
          </div>

          <p className="text-sm text-slate-300 leading-relaxed pt-1">{task.description}</p>

          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 text-xs text-slate-300 space-y-1">
            <span className="font-semibold text-indigo-300 block">🎯 Learning Objective:</span>
            <p className="leading-relaxed">{task.learningObjective}</p>
          </div>
        </div>

        {/* Resources */}
        {task.resources.length > 0 && (
          <div className="mt-5 pt-4 border-t border-slate-800/80">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" /> Curated References
            </h4>
            <div className="flex flex-wrap gap-2">
              {task.resources.map((res, i) => (
                <a
                  key={i}
                  href={res.url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-xs text-indigo-300 transition-colors"
                >
                  <span>{res.title}</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Interview Questions Section (Section 11, 35) */}
        {task.interviewQuestions.length > 0 && (
          <div className="mt-5 pt-4 border-t border-slate-800/80">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-amber-400" /> Interview Question
            </h4>
            <div className="space-y-2">
              {task.interviewQuestions.map(iq => {
                const isExpanded = expandedQuestion === iq.id;
                return (
                  <div
                    key={iq.id}
                    className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2"
                  >
                    <div
                      className="flex items-center justify-between cursor-pointer"
                      onClick={() => setExpandedQuestion(isExpanded ? null : iq.id)}
                    >
                      <span className="text-xs sm:text-sm font-medium text-slate-200">
                        {iq.question}
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-slate-400 flex-shrink-0 ml-2" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0 ml-2" />
                      )}
                    </div>
                    {isExpanded && (
                      <div className="pt-2 border-t border-slate-800 text-xs text-slate-300 leading-relaxed animate-in fade-in">
                        <span className="text-indigo-400 font-semibold block mb-1">Model Answer Key:</span>
                        {iq.answerSummary}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Completion & Reversal Actions */}
        <div className="mt-6 pt-5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs text-slate-400">
            {isCompleted ? (
              <span className="text-emerald-400 font-medium flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Completion permanently recorded in Point Ledger.
              </span>
            ) : (
              <span>Completing today awards <strong className="text-emerald-400">+4 points</strong></span>
            )}
          </div>

          <div className="flex items-center gap-3">
            {!isCompleted ? (
              isNightLockdown ? (
                <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-950/40 border border-purple-500/30 text-xs text-purple-300 font-semibold">
                  <Moon className="w-4 h-4 text-purple-400" />
                  <span>Night Curfew Active • Locked until 04:00 AM</span>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowConfirmModal(true)}
                  className="px-5 py-2.5 rounded-xl font-semibold text-sm bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20 transition-all cursor-pointer flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" /> Mark Complete (+4 pts)
                </button>
              )
            ) : (
              <div className="flex items-center gap-2">
                {isReversalBlocked ? (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-amber-400 font-medium">
                    <Lock className="w-3.5 h-3.5" />
                    <span>{reversalCooldownText}</span>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowReversalModal(true)}
                    className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-amber-400" /> Request Reversal
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. Daily DSA Problem (Section 17, 18) */}
      {dsaProblem && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <Code2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block">
                  Daily DSA Practice • {dsaProblem.category}
                </span>
                <h4 className="text-base font-bold text-slate-100">{dsaProblem.title}</h4>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                +{dsaProblem.points} PTS ({dsaProblem.difficulty})
              </span>
              {dsaSolved ? (
                <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" /> SOLVED
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  UNSOLVED
                </span>
              )}
            </div>
          </div>

          <div className="mt-4 space-y-3 text-xs sm:text-sm text-slate-300">
            <p>{dsaProblem.description}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-400 font-medium">Optimal Approach:</span>{' '}
                <span className="text-slate-200">{dsaProblem.approach}</span>
              </div>
              <div className="sm:text-right">
                <span className="text-slate-400 font-medium">Target Complexity:</span>{' '}
                <span className="text-indigo-300 font-mono">
                  Time: {dsaProblem.timeComplexity} | Space: {dsaProblem.spaceComplexity}
                </span>
              </div>
            </div>
          </div>

          {/* DSA Practice Action */}
          <div className="mt-5 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
            {dsaProblem.leetcodeUrl && (
              <a
                href={dsaProblem.leetcodeUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="inline-flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 font-medium"
              >
                <span>Open Problem in LeetCode / IDE</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}

            {!dsaSolved ? (
              isNightLockdown ? (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-950/40 border border-purple-500/30 text-xs text-purple-300 font-medium">
                  <Moon className="w-3.5 h-3.5 text-purple-400" />
                  <span>Submissions locked during Night Curfew</span>
                </div>
              ) : (
                <form onSubmit={handleDsaSubmit} className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <span>Minutes:</span>
                    <input
                      type="number"
                      min="5"
                      max="180"
                      value={dsaMinutes}
                      onChange={e => setDsaMinutes(parseInt(e.target.value, 10) || 30)}
                      className="w-16 px-2 py-1 bg-slate-950 border border-slate-700 rounded text-slate-200 text-center"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={isSubmittingDsa}
                    className="px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Award className="w-3.5 h-3.5" /> Record Solution (+{dsaProblem.points} pts)
                  </button>
                </form>
              )
            ) : (
              <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> DSA Points Awarded (+{dsaProblem.points} pts)
              </span>
            )}
          </div>
        </div>
      )}

      {/* Confirmation Modal for Marking Task Complete (Section 20) */}
      <ConfirmationModal
        isOpen={showConfirmModal}
        title="Confirm Task Completion"
        message={`Are you sure you completed "${task.title}"?`}
        warningNote="Permanent Action: Once confirmed, this completion is committed to the immutable score ledger (+4 pts) and cannot be directly unchecked without partner approval."
        confirmLabel="Yes, I Completed It"
        cancelLabel="Cancel"
        onConfirm={handleConfirmCompletion}
        onCancel={() => setShowConfirmModal(false)}
      />

      {/* Reversal Request Modal (Section 21) */}
      {showReversalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-100">Request Reversal</h3>
                <p className="text-xs text-slate-400">Two-Person Mutual Approval Workflow</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Your partner will review this reversal request. If approved, the completion points will be
              reverted. If declined, a 12-hour mutual cooldown will be strictly enforced.
            </p>

            <form onSubmit={handleSendReversal} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Reason for Reversal:
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="e.g. Marked complete accidentally before finishing the hands-on project..."
                  value={reversalReason}
                  onChange={e => setReversalReason(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowReversalModal(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" /> Submit to Partner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
